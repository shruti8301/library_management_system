		<div class="span12">
				<div class="header">
				<div class="pull-left">
				<img class="stilogo" src="LMS/vit.png" class="img-rounded">
				</div>
				</div>

					<center><div class="alert alert-info">Welcome to VIT University Library&nbsp;
					
					
					
	
								
							
					</div></center>
				
					
				</div>