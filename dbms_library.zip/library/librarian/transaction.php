<?php include('header.php'); ?>
<?php include('session.php'); ?>
<?php include('navbar_transaction.php'); ?>
    <div class="container">
		<div class="margin-top">
			<div class="row">	
			<div class="span2">			     
										
										 
     <!-- Modal add user -->
	
										
			</div>
		
			</div>
		</div>
    </div>
<?php include('footer.php') ?>