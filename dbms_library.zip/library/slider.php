		
    	<div style="overflow:hidden; width:960px; margin:0 auto; padding:0 20px;"> 
                <div class="pix_diapo">

                    <div data-thumb="LMS/EB1.jpg">
                        <img src="LMS/EB1.jpg">
                    </div>
                    
                    <div data-thumb="LMS/EB2.jpg">
                        <img src="LMS/EB2.jpg"> 
                    </div>
                    
                    <div data-thumb="LMS/EB3.jpg" data-time="7000">
                        <img src="LMS/EB3.jpg">
                    </div>
					
					<div data-thumb="LMS/EB4.jpg">
                        <img src="LMS/EB4.jpg"> 
                    
                    </div>
					<div data-thumb="LMS/EB5.jpg">
                        <img src="LMS/EB5.jpg"> 
                    
                    </div>
					<div data-thumb="LMS/EB6.jpg">
                        <img src="LMS/EB6.jpg"> 
                    
                    </div>
					<div data-thumb="LMS/EB7.jpg">
                        <img src="LMS/EB7.jpg"> 
                    </div>
					
					<div data-thumb="LMS/EB8.jpg">
                        <img src="LMS/EB8.jpg"> 
                    </div>
					
					<div data-thumb="LMS/EB9.jpg" data-time="7000">
                        <img src="LMS/EB9.jpg"> 
                    </div>
               </div><!-- #pix_diapo -->
                
        </div>
    
    
    </section> 