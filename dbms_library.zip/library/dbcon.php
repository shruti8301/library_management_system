<?php
mysql_select_db('eb_lms',mysql_connect('localhost','root',''))or die(mysql_error());
?>